package cookingsys;

import java.util.Scanner;

public class cookingtracking {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input=new Scanner(System.in);
		
		System.out.println("Please Enter number of minutes:");
		float minutes=input.nextFloat();
		float i=5;
		do {
			System.out.println(i);
			++i;
			
			
		}while(minutes<=i);
		
	}

}
